# heysaik - eeg-eye-state-classification
# https://github.com/heysaik/eeg-eye-state-classification/blob/master/PyTorch_EEGEyeState.ipynb
# Add 5 fold using
# https://github.com/christianversloot/machine-learning-articles/blob/main/how-to-use-k-fold-cross-validation-with-pytorch.md

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from net import Net
import time

# Add library
import os
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report
from torch.utils.data import Dataset, DataLoader, ConcatDataset, TensorDataset
from sklearn.model_selection import KFold
from torch.nn.utils.rnn import pad_sequence
from statistics import stdev
#from tqdm import tqdm
import builtins
from sklearn.metrics import accuracy_score

import warnings
warnings.filterwarnings('ignore')
#import random

# (1) import nvflare client API
import nvflare.client as flare

# (optional) metrics
from nvflare.client.tracking import SummaryWriter

# (optional) set a fix place so we don't need to download everytime
# DATASET_PATH = "/tmp/nvflare/data/eye_state"
# (optional) We change to use GPU to speed things up.
# if you want to use CPU, change DEVICE="cpu"
#DEVICE = "cuda:0"
DEVICE = "cpu"

## Train Data
class trainData(Dataset):
    
    def __init__(self, X_data, y_data):
        self.X_data = X_data
        self.y_data = y_data
        
    def __getitem__(self, index):
        return self.X_data[index], self.y_data[index]
        
    def __len__ (self):
        return len(self.X_data)


## Test Data    
class testData(Dataset):
    
    def __init__(self, X_data):
        self.X_data = X_data
        
    def __getitem__(self, index):
        return self.X_data[index]
        
    def __len__ (self):
        return len(self.X_data)

def accuracy_func(y_pred, y_test):
    y_pred_tag = torch.round(torch.sigmoid(y_pred))

    correct_results_sum = (y_pred_tag == y_test).sum().float()
    acc = correct_results_sum/y_test.shape[0]
    acc = torch.round(acc * 100)
    
    return acc

def reset_weights(m):
  '''
    Try resetting model weights to avoid
    weight leakage.
  '''
  for layer in m.children():
   if hasattr(layer, 'reset_parameters'):
    #print(f'Reset trainable parameters of layer = {layer}')
    layer.reset_parameters()
    #dic = m.state_dict()
    #for k in dic:
    #    dic[k] *= 0
    #m.load_state_dict(dic)
    #del(dic)

def collate_fn(data: list[tuple[torch.Tensor, torch.Tensor]]):
    tensors, targets = zip(*data)
    features = pad_sequence(tensors, batch_first=True)
    targets = torch.stack(targets)
    return features, targets

def print_class(y_train, y_test):
    print ("----------------------")
    print ("Train data distribution")
    print (f'Class 0 (eye open):{y_train.value_counts()[0]} being about {y_train.value_counts()[0]/(y_train.value_counts()[0]+y_train.value_counts()[1]):.3f}%')
    print (f'Class 1 (eye close):{y_train.value_counts()[1]} being about {y_train.value_counts()[1]/(y_train.value_counts()[0]+y_train.value_counts()[1]):.3f}%')
    print ("----------------------")
    print ("Test data distribution")
    print (f'Class 0 (eye open):{y_test.value_counts()[0]} being about {y_test.value_counts()[0]/(y_test.value_counts()[0]+y_test.value_counts()[1]):.3f}%')
    print (f'Class 1 (eye close):{y_test.value_counts()[1]} being about {y_test.value_counts()[1]/(y_test.value_counts()[0]+y_test.value_counts()[1]):.3f}%')
    print ("----------------------")

def main():
    st = time.time()
    sub_train = '/home/plaipmc/eegfl/NVFlare/examples/hello-world/eyestate_S2C1/data/S039_train.csv'
    sub_valid = '/home/plaipmc/eegfl/NVFlare/examples/hello-world/eyestate_S2C1/data/S039_valid.csv'
    sub_test = '/home/plaipmc/eegfl/NVFlare/examples/hello-world/eyestate_S2C1/data/S039_test.csv'
    # Data downloading
    data_train = pd.read_csv(sub_train)
    X_train = data_train.iloc[:,0:64]
    y_train = data_train.iloc[:,64]
    data_valid = pd.read_csv(sub_valid)
    X_valid = data_valid.iloc[:,0:64]
    y_valid = data_valid.iloc[:,64]
    data_test = pd.read_csv(sub_test)
    X_test = data_test.iloc[:,0:64]
    y_test = data_test.iloc[:,64]
    random_state_set = 1000
    # Data preparation
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_valid = scaler.fit_transform(X_valid)
    X_test = scaler.fit_transform(X_test)
    train_data = trainData(torch.FloatTensor(X_train), torch.FloatTensor(y_train.values))
    valid_data = testData(torch.FloatTensor(X_valid))
    test_data = testData(torch.FloatTensor(X_test))

    BATCH_SIZE = 64
    LEARNING_RATE = 0.001
    EPOCHS = 5

    train_loader = DataLoader(dataset=train_data, batch_size=BATCH_SIZE, shuffle=True)
    valid_loader = DataLoader(dataset=valid_data, batch_size=1)
    test_loader = DataLoader(dataset=test_data, batch_size=1)

    net = Net()
    # (2) initializes NVFlare client API
    flare.init()
    summary_writer = SummaryWriter()
    while flare.is_running():
        # (3) receives FLModel from NVFlare
        input_model = flare.receive()
        print(f"current_round={input_model.current_round}")

        # (4) loads model from NVFlare
        net.load_state_dict(input_model.params)

        criterion = nn.BCEWithLogitsLoss()
        optimizer = optim.Adam(net.parameters(), lr=LEARNING_RATE)

        net.to(DEVICE)
        criterion = criterion.to(DEVICE)

        net.train()
        for e in range(1, EPOCHS+1):
            epoch_loss = 0
            epoch_acc = 0
            for X_batch, y_batch in train_loader:
                X_batch, y_batch = X_batch.to(DEVICE), y_batch.to(DEVICE)
                optimizer.zero_grad()

                y_pred = net(X_batch)
                loss = criterion(y_pred, y_batch.unsqueeze(1))
                acc = accuracy_func(y_pred, y_batch.unsqueeze(1))

                loss.backward()
                optimizer.step()

                epoch_loss += loss.item()
                epoch_acc += acc.item()

            print(f'Epoch {e+0:03}: | Loss: {epoch_loss/len(train_loader):.5f} | Acc: {epoch_acc/len(train_loader):.3f}')

    print("Finished Training")

    y_pred_list = []
    net.eval()
    with torch.no_grad():
        for X_batch in valid_loader:
            X_batch = X_batch.to(DEVICE)
            y_test_pred = net(X_batch)
            y_test_pred = torch.sigmoid(y_test_pred)
            y_pred_tag = torch.round(y_test_pred)
            y_pred_list.append(y_pred_tag.cpu().numpy())

    y_pred_list = [a.squeeze().tolist() for a in y_pred_list]

    tn, fp, fn, tp = confusion_matrix(y_valid, y_pred_list).ravel()
    print("Accuracy : ",accuracy_score(y_valid, y_pred_list))
    print("Sensitivity : ", tp/(tp+fn))

    et = time.time()
    elapsed_time = et - st
    print('Execution time:', elapsed_time, 'seconds')
    pytorch_total_params = builtins.sum(p.numel() for p in net.parameters())
    pytorch_total_train_params = builtins.sum(p.numel() for p in net.parameters() if p.requires_grad)
    print('Total parameters:', pytorch_total_params)
    print('Total trainable parameters:', pytorch_total_train_params)

    PATH = "./eyestate_net.pth"
    torch.save(net.state_dict(), PATH)
    
    # Main loop for testing
    def evaluate(input_weights):
        net = Net()
        net.load_state_dict(input_weights)
        # (optional) use GPU to speed things up
        net.to(DEVICE)
        y_pred_list = []
        net.eval()
        with torch.no_grad():
            for X_batch in test_loader:
                X_batch = X_batch.to(DEVICE)
                y_test_pred = net(X_batch)
                y_test_pred = torch.sigmoid(y_test_pred)
                y_pred_tag = torch.round(y_test_pred)
                y_pred_list.append(y_pred_tag.cpu().numpy())
        y_pred_list = [a.squeeze().tolist() for a in y_pred_list]
        tn, fp, fn, tp = confusion_matrix(y_test, y_pred_list).ravel()
        print ("Accuracy : ",accuracy_score(y_test, y_pred_list))
        print ("Sensitivity : ", tp/(tp+fn))
        et = time.time()
        elapsed_time = et - st
        print('Execution time:', elapsed_time, 'seconds')
        pytorch_total_params = builtins.sum(p.numel() for p in net.parameters())
        pytorch_total_train_params = builtins.sum(p.numel() for p in net.parameters() if p.requires_grad)
        print('Total parameters:', pytorch_total_params)
        print('Total trainable parameters:', pytorch_total_train_params)
        print()
        return accuracy_score(y_test, y_pred_list)
    # (6) evaluate on received model for model selection
    accuracy = evaluate(input_model.params)
    # (7) construct trained FL model
    output_model = flare.FLModel(
            params=net.cpu().state_dict(),
            metrics={"accuracy": accuracy},
            meta={"NUM_STEPS_CURRENT_ROUND": steps},
    )
    # (8) send model back to NVFlare
    flare.send(output_model)

if __name__ == "__main__":
    main()
