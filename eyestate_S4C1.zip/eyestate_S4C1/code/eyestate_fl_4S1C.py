# heysaik - eeg-eye-state-classification
# https://github.com/heysaik/eeg-eye-state-classification/blob/master/PyTorch_EEGEyeState.ipynb
# Add 5 fold using
# https://github.com/christianversloot/machine-learning-articles/blob/main/how-to-use-k-fold-cross-validation-with-pytorch.md
# not done yet

import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from net import Net
#import time

# Add library
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report
from torch.utils.data import Dataset, DataLoader, ConcatDataset, TensorDataset
from sklearn.model_selection import KFold
from torch.nn.utils.rnn import pad_sequence
from statistics import stdev
#from tqdm import tqdm
import builtins
from sklearn.metrics import accuracy_score

import warnings
warnings.filterwarnings('always')

# (optional) set a fix place so we don't need to download everytime
# DATASET_PATH = "/tmp/nvflare/data/eye_state"
# (optional) We change to use GPU to speed things up.
# if you want to use CPU, change DEVICE="cpu"
# DEVICE = "cuda:0"
DEVICE = "cpu"

# (1) import nvflare client API
import nvflare.client as flare

## Train Data
class trainData(Dataset):
    
    def __init__(self, X_data, y_data):
        self.X_data = X_data
        self.y_data = y_data
        
    def __getitem__(self, index):
        return self.X_data[index], self.y_data[index]
        
    def __len__ (self):
        return len(self.X_data)


## Test Data    
class testData(Dataset):
    
    def __init__(self, X_data):
        self.X_data = X_data
        
    def __getitem__(self, index):
        return self.X_data[index]
        
    def __len__ (self):
        return len(self.X_data)

def accuracy_func(y_pred, y_test):
    y_pred_tag = torch.round(torch.sigmoid(y_pred))

    correct_results_sum = (y_pred_tag == y_test).sum().float()
    acc = correct_results_sum/y_test.shape[0]
    acc = torch.round(acc * 100)
    
    return acc

def reset_weights(m):
  '''
    Try resetting model weights to avoid
    weight leakage.
  '''
  for layer in m.children():
   if hasattr(layer, 'reset_parameters'):
    #print(f'Reset trainable parameters of layer = {layer}')
    layer.reset_parameters()
    #dic = m.state_dict()
    #for k in dic:
    #    dic[k] *= 0
    #m.load_state_dict(dic)
    #del(dic)

def collate_fn(data: list[tuple[torch.Tensor, torch.Tensor]]):
    tensors, targets = zip(*data)
    features = pad_sequence(tensors, batch_first=True)
    targets = torch.stack(targets)
    return features, targets

def print_class(y_train_print, y_test_print):
    print ("----------------------")
    print ("Train data distribution")
    print(f'Train class 0 : {y_train_print.count(0)} about {y_train_print.count(0)/(y_train_print.count(0)+y_train_print.count(1)):.3f}%')
    print(f'Train class 1 : {y_train_print.count(1)} about {y_train_print.count(1)/(y_train_print.count(0)+y_train_print.count(1)):.3f}%')
    print ("----------------------")
    print ("Test data distribution")
    print(f'Test class 0 : {y_test_print.count(0)} about {y_test_print.count(0)/(y_test_print.count(0)+y_test_print.count(1)):.3f}%')
    print(f'Test class 1 : {y_test_print.count(1)} about {y_test_print.count(1)/(y_test_print.count(0)+y_test_print.count(1)):.3f}%')
    print ("----------------------")

def main():
    #st = time.time()
    # Data loading and preprocessing
    subject = 'S064'
    data_train = pd.read_csv('/home/plaipmc/eegfl/NVFlare/examples/hello-world/eyestate_4Subjects_splitclients_1C/data/'+subject+'_train')
    data_valid = pd.read_csv('/home/plaipmc/eegfl/NVFlare/examples/hello-world/eyestate_4Subjects_splitclients_1C/data/'+subject+'_valid')
    data_test = pd.read_csv('/home/plaipmc/eegfl/NVFlare/examples/hello-world/eyestate_4Subjects_splitclients_1C/data/'+subject+'_test')
    X_train = data_train.iloc[:,0:64]
    y_train = data_train.iloc[:,64]
    X_valid = data_valid.iloc[:,0:64]
    y_valid = data_valid.iloc[:,64]
    X_test = data_test.iloc[:,0:64]
    y_test = data_test.iloc[:,64]
    
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_valid = scaler.fit_transform(X_valid)
    X_test = scaler.fit_transform(X_test)

    train_data = trainData(torch.FloatTensor(X_train), torch.FloatTensor(y_train.values))
    valid_data = testData(torch.FloatTensor(X_valid))
    train_loader = DataLoader(dataset=train_data, batch_size=BATCH_SIZE, shuffle=True)
    valid_loader = DataLoader(dataset=valid_data, batch_size=1)

    DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    BATCH_SIZE = 64
    LEARNING_RATE = 0.001
    EPOCHS = 50
    
    # Start print
    print('--------------------------------')
    # (2) initializes NVFlare client API
    flare.init()

    while flare.is_running():
        # (3) receives FLModel from NVFlare
        input_model = flare.receive()
        print(f"current_round={input_model.current_round}")
        net = Net()

            
        # (4) loads model from NVFlare
        net.load_state_dict(input_model.params)
        #net.apply(reset_weights)

        criterion = nn.BCEWithLogitsLoss()
        optimizer = optim.Adam(net.parameters(), lr=LEARNING_RATE)

        # (optional) use GPU to speed things up
        net.to(DEVICE)
        criterion = criterion.to(DEVICE)
        steps = EPOCHS * len(train_loader)

        #net.train()
        for e in range(1, EPOCHS+1):
            epoch_loss = 0
            epoch_acc = 0
            
            for X_batch, y_batch in train_loader:
                optimizer.zero_grad()
                y_trainp.append(y_batch.numpy().tolist())
                y_pred = net(X_batch)
                loss = criterion(y_pred, y_batch.unsqueeze(1))
                acc = accuracy_func(y_pred, y_batch.unsqueeze(1))
                
                loss.backward()
                optimizer.step()
                
                epoch_loss += loss.item()
                epoch_acc += acc.item()
            
            print(f'Epoch {e+0:03}: | Loss: {epoch_loss/len(train_loader):.5f} | Acc: {epoch_acc/len(train_loader):.3f}')

        print("Finished Training")

        PATH = "./eye_state_net"+"_"+str(subject)+".pth"
        torch.save(net.state_dict(), PATH)

        net = Net()
        net.load_state_dict(torch.load(PATH))
        # (optional) use GPU to speed things up
        net.to(DEVICE)

        y_pred_list = []
        net.eval()
        with torch.no_grad():
            for X_batch in valid_loader:
                X_batch = X_batch.to(DEVICE)
                y_test_pred = net(X_batch)
                y_test_pred = torch.sigmoid(y_test_pred)
                y_pred_tag = torch.round(y_test_pred)
                y_pred_list.append(y_pred_tag.cpu().numpy())

        y_pred_list = [a.squeeze().tolist() for a in y_pred_list]

        print_class(y_train, y_valid)
        print(classification_report(y_valid, y_pred_list))
        tn, fp, fn, tp = confusion_matrix(y_valid, y_pred_list).ravel()
        #print("Accuracy : ",accuracy_score(y_valid, y_pred_list))
        #print ("Sensitivity : ", tp/(tp+fn))
        
        net = Net()
        net.load_state_dict(torch.load(PATH))
        # (optional) use GPU to speed things up
        net.to(DEVICE)
        PATH = "./cifar_net.pth"
        torch.save(net.state_dict(), PATH)

        # (5) wraps evaluation logic into a method to re-use for
        #       evaluation on both trained and received model
        def evaluate(input_weights):
            net = Net()
            net.load_state_dict(input_weights)
            # (optional) use GPU to speed things up
            net.to(DEVICE)
            # Test
            #print ("----------------------")
            #print ("Test data distribution")
            #print(f'Test class 0 : {(y_test_last == 0.0).sum()} about {(y_test_last == 0.0).sum()/((y_test_last == 0.0).sum()+(y_test_last == 1.0).sum()):.3f}%')
            #print(f'Test class 1 : {(y_test_last == 1.0).sum()} about {(y_test_last == 1.0).sum()/((y_test_last == 0.0).sum()+(y_test_last == 1.0).sum()):.3f}%')
            #print ("----------------------")
            test_data = testData(torch.FloatTensor(X_test))
            test_loader = DataLoader(dataset=test_data, batch_size=1)
            net.eval()
            y_pred_final = []
            # since we're not training, we don't need to calculate the gradients for our outputs
            with torch.no_grad():
                for X_batch in test_loader:
                    X_batch = X_batch.to(DEVICE)
                    y_test_pred = net(X_batch)
                    y_test_pred = torch.sigmoid(y_test_pred)
                    y_pred_tag = torch.round(y_test_pred)
                    y_pred_final.append(int(y_pred_tag.cpu()[0,0].tolist()))
            print(classification_report(y_test, y_pred_final))
            return accuracy_score(y_test, y_pred_final)
            
        # (6) evaluate on received model for model selection
        accuracy = evaluate(input_model.params)
        # (7) construct trained FL model
        output_model = flare.FLModel(
            params=net.cpu().state_dict(),
            metrics={"accuracy": accuracy},
            meta={"NUM_STEPS_CURRENT_ROUND": steps},
        )
        # (8) send model back to NVFlare
        flare.send(output_model)

if __name__ == "__main__":
    main()
